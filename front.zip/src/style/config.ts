
let config = {
    mainColor: '#e0e0e0',
	secondaryColor: '#000000',
	thirdColor: '#212121',
	logo: "https://i.pinimg.com/originals/95/3b/24/953b24b6385bb183e2cb61e188bca124.png",
	styleLogo: {
		width: '6em',
		height: '1.5em'
	}
}

export default config;